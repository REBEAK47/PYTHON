#REBEAK PAUL SINGH SMX2C
while True:
    # Demanar els dos números per fer el càlcul
    num1 = float(input("Introdueix el primer número: "))  # Demana el primer número a l'usuari
    num2 = float(input("Introdueix el segon número: "))   # Demana el segon número a l'usuari
    operacio = input("Introdueix l'operació (+, -, *, /, %): ")  # Demana l'operació que vol realitzar

    # Fa el càlcul segons l'operació
    if operacio == "+":
        resultat = num1 + num2  # Suma
    elif operacio == "-":
        resultat = num1 - num2  # Resta
    elif operacio == "*":
        resultat = num1 * num2  # Multiplicació
    elif operacio == "/":
        resultat = num1 / num2 if num2 != 0 else "Error: Divisió per zero"  # Divisió, comprovant que el divisor no sigui zero
    elif operacio == "%":
        resultat = num1 % num2 if num2 != 0 else "Error: Divisió per zero"  # Mòdul, comprovant que el divisor no sigui zero
    else:
        print("Operació no vàlida. Sortint del programa.")  # Missatge d'error si l'operació no és vàlida
        break  # Surt del bucle si l'operació no és vàlida

    # Mostra el resultat de l'operació
    print("El resultat és: {}\n".format(resultat))  # Mostra el resultat de l'operació
