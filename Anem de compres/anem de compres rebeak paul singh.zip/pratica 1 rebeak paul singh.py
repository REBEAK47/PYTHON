#REBEAK PAUL SINGH SMX2C
# Aquí es farà la pregunta al client
dni = int(input("Introdueix el DNI (sense la lletra): "))  # Demana el DNI sense la lletra
preu = float(input("Introdueix el preu de l'article: "))  # Demana el preu de l'article
descompte = float(input("Percentatge de descompte: "))  # Demana el percentatge de descompte
iva = float(input("Percentatge d'IVA: "))  # Demana el percentatge d'IVA

# Es farà el càlcul de la lletra del NIF
lletra = "TRWAGMYFPDXBNJZSQVHLCKE"[dni % 23]  # Càlcul de la lletra del NIF
nif = "{}{}".format(dni, lletra)  # Formata el NIF

# Ens dirà el càlcul del preu final
preu_final = preu * (1 - descompte / 100) * (1 + iva / 100)  # Càlcul del preu final

print("El NIF del client és: {}".format(nif))  # Mostra el NIF del client
print("El preu final de l'article és: {:.2f} euros".format(preu_final))  # Mostra el preu final
