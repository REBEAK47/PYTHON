#REBEAK PAUL SINGH SMX2C
import random  # Importar la biblioteca random per generar nombres aleatoris

def joc_de_endevinar():
    numero = random.randint(1, 100)  # Generar un número aleatori entre 1 i 100
    intents = 0  # Inicialitzar el comptador d'intents

    while intents < 5:  # Bucle que s'executa mentre els intents siguin menys de 5
        endevina = int(input("Quin número he pensat? "))  # Demanar a l'usuari que endevini el número
        intents += 1  # Incrementar el comptador d'intents

        if endevina < numero:
            print("És més gran")  # Indicar que el número és més gran
        elif endevina > numero:
            print("És més petit")  # Indicar que el número és més petit
        else:
            print("Has encertat en {} intents!".format(intents))  # Felicitar a l'usuari si endevina
            return  # Sortir de la funció si l'usuari endevina correctament

    print("No has encertat. El número era {}.".format(numero))  # Missatge final si no s'endevina en 5 intents

joc_de_endevinar()  # Cridar la funció
