#REBEAK PAUL SINGH SMX2C
def crear_menu():
    menu = []  # Inicialitzem una llista buida per guardar els plats i els seus preus
    while len(menu) < 8:  # Continuem fins que tinguem almenys 8 plats
        nom = input("Nom del plat: ")  # Demanem el nom del plat
        if nom == '$':  # Si el nom és '$', sortim del bucle
            break
        preu = float(input("Preu del plat: "))  # Demanem el preu del plat
        if preu <= 0:  # Si el preu és 0 o negatiu, sortim del bucle
            break
        menu.append((nom, preu))  # Afegim el plat i el seu preu a la llista
    return menu  # Retornem la llista de plats

def mostrar_menu(menu):
    for i, (nom, preu) in enumerate(menu, 1):  # Enumerem els plats per mostrar-los amb un número
        print(f"{i} - {nom} ... {preu}€")  # Imprimim cada plat amb el seu preu
    print("0 - PAGAR")  # Afegim l'opció de pagar

def prendre_comanda(menu):
    total = 0  # Inicialitzem el total a 0
    while True:
        opcio = int(input("Què volen dinar? "))  # Demanem al client què vol menjar
        if opcio == 0:  # Si l'opció és 0, sortim del bucle
            break
        total += menu[opcio - 1][1]  # Afegim el preu del plat seleccionat al total
    print(f"L'import total és {total}€.")  # Imprimim el total a pagar

menu = crear_menu()  # Creem el menú
mostrar_menu(menu)  # Mostrem el menú
prendre_comanda(menu)  # Prenem la comanda del client
